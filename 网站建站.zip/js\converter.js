import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

// ============================================
// 配置区 — 部署 Cloudflare Worker 后替换此 URL
// ============================================
const CORS_PROXY = 'https://proud-dust-1b4c.19871350631.workers.dev/';

// ============================================
// DOM 元素
// ============================================
const el = {
  urlInput: document.getElementById('m3u8Url'),
  convertBtn: document.getElementById('convertBtn'),
  progressContainer: document.getElementById('progressContainer'),
  progressFill: document.getElementById('progressFill'),
  progressText: document.getElementById('progressText'),
  fileList: document.getElementById('fileList'),
  statusMsg: document.getElementById('statusMsg'),
  downloadArea: document.getElementById('downloadArea'),
  downloadBtn: document.getElementById('downloadBtn'),
  fileInfo: document.getElementById('fileInfo'),
};

// ============================================
// 状态
// ============================================
let ffmpeg = null;
let ffmpegLoaded = false;
let isConverting = false;
let outputData = null;
let outputFilename = 'output.mp4';

// ============================================
// FFmpeg 初始化（只加载一次）
// ============================================
async function getFFmpeg() {
  if (ffmpegLoaded) return ffmpeg;

  showStatus('info', '正在加载转换引擎（约 31MB），首次加载可能需要几秒...');
  el.convertBtn.disabled = true;

  try {
    ffmpeg = new FFmpeg();

    // 监听进度
    ffmpeg.on('progress', ({ progress, time }) => {
      // progress: 0-1 范围
      const percent = Math.round(progress * 100);
      el.progressFill.style.width = percent + '%';
      if (time) {
        el.progressText.textContent = `转换中... ${percent}% （已处理 ${formatTime(time)}）`;
      } else {
        el.progressText.textContent = `转换中... ${percent}%`;
      }
    });

    // 监听日志（调试用，生产环境可关闭）
    ffmpeg.on('log', ({ message }) => {
      console.log('[ffmpeg]', message);
    });

    // 加载单线程版本（无需 SharedArrayBuffer）
    const corePath = await toBlobURL(
      'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js',
      'text/javascript'
    );
    const wasmPath = await toBlobURL(
      'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.wasm',
      'application/wasm'
    );

    await ffmpeg.load({ corePath, wasmPath });
    ffmpegLoaded = true;
    hideStatus();
    return ffmpeg;
  } catch (err) {
    console.error('FFmpeg 加载失败:', err);
    showStatus('error', '转换引擎加载失败。请刷新页面后重试。如果问题持续，请检查网络连接。');
    el.convertBtn.disabled = false;
    throw err;
  }
}

// ============================================
// M3U8 解析
// ============================================
function parseM3U8(content, baseUrl) {
  const lines = content.split('\n');
  const segments = [];
  let isMasterPlaylist = false;

  for (const line of lines) {
    const trimmed = line.trim();

    // 跳过空行
    if (trimmed === '') continue;

    // 检测是否为多码率主播放列表
    if (trimmed.startsWith('#EXT-X-STREAM-INF')) {
      isMasterPlaylist = true;
      continue;
    }

    // 跳过所有标签行（以 # 开头）
    if (trimmed.startsWith('#')) continue;

    // 处理分段 URL（相对路径 → 绝对路径）
    let segmentUrl = trimmed;
    if (!segmentUrl.startsWith('http://') && !segmentUrl.startsWith('https://')) {
      const base = baseUrl.substring(0, baseUrl.lastIndexOf('/') + 1);
      segmentUrl = base + segmentUrl;
    }
    segments.push(segmentUrl);
  }

  return { segments, isMasterPlaylist };
}

// ============================================
// 通过 CORS 代理获取文件
// ============================================
async function fetchViaProxy(url) {
  const proxyUrl = CORS_PROXY + encodeURIComponent(url);
  const response = await fetch(proxyUrl);
  if (!response.ok) {
    throw new Error(`请求失败 (${response.status}): ${url.substring(0, 80)}...`);
  }
  return response;
}

// ============================================
// 主转换流程
// ============================================
async function startConversion() {
  if (isConverting) return;

  const m3u8Url = el.urlInput.value.trim();
  if (!m3u8Url) {
    showStatus('error', '请输入 M3U8 链接');
    return;
  }

  // 验证 URL
  try {
    new URL(m3u8Url);
  } catch {
    showStatus('error', '请输入有效的 URL 地址');
    return;
  }

  // 重置界面
  isConverting = true;
  hideStatus();
  el.downloadArea.classList.remove('show');
  el.progressContainer.style.display = 'block';
  el.progressFill.style.width = '0%';
  el.progressText.textContent = '准备中...';
  el.fileList.innerHTML = '';
  el.convertBtn.disabled = true;
  outputData = null;

  try {
    // Step 1: 初始化 FFmpeg
    const ff = await getFFmpeg();

    // Step 2: 获取并解析 M3U8
    el.progressText.textContent = '正在获取 M3U8 播放列表...';
    const playlistResp = await fetchViaProxy(m3u8Url);
    const playlistContent = await playlistResp.text();
    const { segments, isMasterPlaylist } = parseM3U8(playlistContent, m3u8Url);

    if (segments.length === 0) {
      if (isMasterPlaylist) {
        throw new Error(
          '检测到多码率主播放列表（Master Playlist）。请直接使用具体分辨率的 M3U8 链接。\n\n' +
          '提示：在浏览器开发者工具 → 网络 中找到以 .m3u8 结尾的具体子链接，通常包含分辨率数字如 720、1080 等。'
        );
      }
      throw new Error('未在 M3U8 文件中找到任何视频分片。请检查链接是否正确。');
    }

    // Step 3: 下载所有 TS 分片
    el.progressText.textContent = `正在下载视频分片 (0/${segments.length})...`;
    el.progressFill.style.width = '5%';

    const segmentFiles = [];
    for (let i = 0; i < segments.length; i++) {
      const segUrl = segments[i];
      const segName = `seg_${String(i).padStart(4, '0')}.ts`;

      // 更新进度
      const downloadPercent = 5 + Math.round((i / segments.length) * 50);
      el.progressFill.style.width = downloadPercent + '%';
      el.progressText.textContent = `正在下载视频分片 (${i + 1}/${segments.length})...`;
      addFileItem(segName, 'current');

      try {
        const resp = await fetchViaProxy(segUrl);
        const data = new Uint8Array(await resp.arrayBuffer());
        await ff.writeFile(segName, data);
        segmentFiles.push(segName);
        updateFileItem(segName, 'done');
      } catch (err) {
        updateFileItem(segName, 'error');
        console.error(`分片 ${i + 1} 下载失败:`, err.message);
        // 继续尝试下载剩余分片
      }
    }

    if (segmentFiles.length === 0) {
      throw new Error('所有视频分片下载失败。视频源可能已失效或需要特殊访问权限。');
    }

    if (segmentFiles.length < segments.length) {
      console.warn(`${segments.length - segmentFiles.length} 个分片下载失败，将尝试用剩余分片合并`);
    }

    // Step 4: 创建合并文件列表
    el.progressText.textContent = '正在合并转换中...';
    el.progressFill.style.width = '60%';

    const concatContent = segmentFiles.map(f => `file '${f}'`).join('\n');
    await ff.writeFile('concat_list.txt', concatContent);

    // Step 5: 执行 ffmpeg 合并转换
    el.progressText.textContent = '正在合并转换...';
    el.progressFill.style.width = '70%';

    outputFilename = 'video_' + Date.now() + '.mp4';
    await ff.exec([
      '-f', 'concat',
      '-safe', '0',
      '-i', 'concat_list.txt',
      '-c', 'copy',
      outputFilename
    ]);

    // Step 6: 读取输出文件
    el.progressText.textContent = '正在准备下载...';
    el.progressFill.style.width = '90%';

    outputData = await ff.readFile(outputFilename);

    // Step 7: 清理虚拟文件系统
    for (const f of segmentFiles) {
      try { await ff.deleteFile(f); } catch (e) { /* ignore */ }
    }
    try { await ff.deleteFile('concat_list.txt'); } catch (e) { /* ignore */ }

    // 完成
    el.progressFill.style.width = '100%';
    el.progressText.textContent = '转换完成！';
    el.downloadArea.classList.add('show');
    el.fileInfo.textContent = `文件大小: ${formatSize(outputData.length)} | 共 ${segmentFiles.length} 个分片`;
    showStatus('success', '转换成功！点击下方按钮下载 MP4 文件。');

  } catch (err) {
    console.error('转换失败:', err);
    showStatus('error', '转换失败: ' + err.message);
  } finally {
    isConverting = false;
    el.convertBtn.disabled = false;
  }
}

// ============================================
// 下载功能
// ============================================
function downloadFile() {
  if (!outputData) return;

  const blob = new Blob([outputData.buffer], { type: 'video/mp4' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = outputFilename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ============================================
// 辅助函数
// ============================================
function showStatus(type, message) {
  el.statusMsg.className = 'status-msg ' + type;
  el.statusMsg.textContent = message;
}

function hideStatus() {
  el.statusMsg.className = 'status-msg';
  el.statusMsg.textContent = '';
}

function addFileItem(name, status) {
  const div = document.createElement('div');
  div.className = 'file-item ' + status;
  div.id = 'file-' + name;
  div.innerHTML = `<span>${name}</span><span>${status === 'current' ? '下载中...' : ''}</span>`;
  el.fileList.appendChild(div);
}

function updateFileItem(name, status) {
  const div = document.getElementById('file-' + name);
  if (div) {
    div.className = 'file-item ' + status;
    const icon = status === 'done' ? '✓' : status === 'error' ? '✗' : '';
    div.querySelector('span:last-child').textContent = icon;
  }
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
}

function formatTime(microseconds) {
  const totalSec = microseconds / 1_000_000;
  const min = Math.floor(totalSec / 60);
  const sec = Math.floor(totalSec % 60);
  return `${min}:${String(sec).padStart(2, '0')}`;
}

// ============================================
// 事件绑定
// ============================================
el.convertBtn.addEventListener('click', startConversion);
el.downloadBtn.addEventListener('click', downloadFile);

// 回车键触发转换
el.urlInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !isConverting) {
    startConversion();
  }
});
